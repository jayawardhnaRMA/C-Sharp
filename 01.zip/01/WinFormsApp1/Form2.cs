﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        public string username;
        public int password;
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            movepanel(button2);

        }

        private void movepanel(Control btn)
        {
            panel3.Top = btn.Top;
            panel3.Height = btn.Height;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            movepanel(button1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            movepanel(button3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            movepanel(button4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            movepanel(button5);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label_time.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer1.Start();
            label_username.Text = username; 

        }
    }
}
