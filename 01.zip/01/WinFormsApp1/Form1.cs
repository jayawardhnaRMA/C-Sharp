
using System.Collections.Generic;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;





namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=akila;Integrated Security=True;Encrypt=False");


        private void button1_Click(object sender, EventArgs e)
        {


            //+++++++++++++++++++++++++++++++++++++++++++++++++++//

            string username, pw;

            username = text_user.Text;
            pw = text_password.Text;

            try
            {
                string query = "SELECT username,password FROM Table_1 WHERE username='" + text_user.Text + "' AND password='" + text_password.Text + "'";

                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(pw))
                {
                    MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Login sucess ");
                }
                else
                {
                    MessageBox.Show("Invalid login credintials,please check Username and Password and try again", "Invalid Login Deatils", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                con.Close();
            }



        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox2, "Hide password");
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox3, "Show password");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox2.Hide();
            text_password.UseSystemPasswordChar = true;
            pictureBox3.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox3.Hide();
            text_password.UseSystemPasswordChar = false;
            pictureBox2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
