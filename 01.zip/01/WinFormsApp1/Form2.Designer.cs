﻿namespace WinFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            panel4 = new Panel();
            panel6 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel5 = new Panel();
            panel7 = new Panel();
            label_time = new Label();
            label_username = new Label();
            label_wellcome = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            panel7.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(243, 486);
            panel1.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel6);
            panel4.Location = new Point(238, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(420, 100);
            panel4.TabIndex = 1;
            // 
            // panel6
            // 
            panel6.Location = new Point(3, 3);
            panel6.Name = "panel6";
            panel6.Size = new Size(665, 60);
            panel6.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightSeaGreen;
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Location = new Point(0, 101);
            panel2.Name = "panel2";
            panel2.Size = new Size(243, 382);
            panel2.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Honeydew;
            panel3.Location = new Point(46, 5);
            panel3.Name = "panel3";
            panel3.Size = new Size(10, 49);
            panel3.TabIndex = 0;
            panel3.Paint += panel3_Paint;
            // 
            // button5
            // 
            button5.BackColor = Color.LightSeaGreen;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(62, 207);
            button5.Name = "button5";
            button5.Size = new Size(178, 51);
            button5.TabIndex = 5;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.LightSeaGreen;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Location = new Point(62, 156);
            button4.Name = "button4";
            button4.Size = new Size(178, 51);
            button4.TabIndex = 4;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.LightSeaGreen;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(62, 105);
            button3.Name = "button3";
            button3.Size = new Size(178, 51);
            button3.TabIndex = 3;
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.LightSeaGreen;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(62, 54);
            button2.Name = "button2";
            button2.Size = new Size(178, 51);
            button2.TabIndex = 2;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.LightSeaGreen;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(62, 0);
            button1.Name = "button1";
            button1.Size = new Size(178, 54);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel5
            // 
            panel5.Location = new Point(241, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(665, 60);
            panel5.TabIndex = 1;
            // 
            // panel7
            // 
            panel7.Controls.Add(label_time);
            panel7.Controls.Add(label_username);
            panel7.Controls.Add(label_wellcome);
            panel7.Location = new Point(241, 69);
            panel7.Name = "panel7";
            panel7.Size = new Size(665, 60);
            panel7.TabIndex = 1;
            panel7.Paint += panel7_Paint;
            // 
            // label_time
            // 
            label_time.AutoSize = true;
            label_time.Location = new Point(107, 32);
            label_time.Name = "label_time";
            label_time.Size = new Size(27, 15);
            label_time.TabIndex = 0;
            label_time.Text = "   @";
            // 
            // label_username
            // 
            label_username.AutoSize = true;
            label_username.Location = new Point(356, 32);
            label_username.Name = "label_username";
            label_username.Size = new Size(12, 15);
            label_username.TabIndex = 0;
            label_username.Text = "-";
            // 
            // label_wellcome
            // 
            label_wellcome.AutoSize = true;
            label_wellcome.Location = new Point(17, 32);
            label_wellcome.Name = "label_wellcome";
            label_wellcome.Size = new Size(70, 15);
            label_wellcome.TabIndex = 0;
            label_wellcome.Text = "WELLCOME";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(903, 479);
            Controls.Add(panel7);
            Controls.Add(panel5);
            Controls.Add(panel1);
            Font = new Font("Segoe UI", 9F);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button button1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Label label_time;
        private Label label_wellcome;
        private System.Windows.Forms.Timer timer1;
        private Label label_username;
    }
}