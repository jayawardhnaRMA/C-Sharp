﻿namespace WinFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            button1 = new Button();
            textBox_usernameS = new TextBox();
            label1 = new Label();
            tabPage2 = new TabPage();
            button_add = new Button();
            textBox_passwordA = new TextBox();
            textBox_usernameA = new TextBox();
            label_password = new Label();
            label_username = new Label();
            tabPage3 = new TabPage();
            button_delete = new Button();
            button_update = new Button();
            textBox_passwordU = new TextBox();
            textBox_usdernameU = new TextBox();
            label2 = new Label();
            label3 = new Label();
            tabPage4 = new TabPage();
            dataGridView2 = new DataGridView();
            button_show = new Button();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.AccessibleRole = AccessibleRole.None;
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Location = new Point(98, 63);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(621, 349);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(dataGridView1);
            tabPage1.Controls.Add(button1);
            tabPage1.Controls.Add(textBox_usernameS);
            tabPage1.Controls.Add(label1);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(613, 321);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "tabPage1";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridView1.Location = new Point(151, 128);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(344, 176);
            dataGridView1.TabIndex = 3;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.HeaderText = "User name";
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.HeaderText = "Password";
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // button1
            // 
            button1.Location = new Point(420, 36);
            button1.Name = "button1";
            button1.Size = new Size(75, 24);
            button1.TabIndex = 2;
            button1.Text = "SHEARCH";
            button1.UseVisualStyleBackColor = true;
            // 
            // textBox_usernameS
            // 
            textBox_usernameS.Location = new Point(229, 37);
            textBox_usernameS.Name = "textBox_usernameS";
            textBox_usernameS.Size = new Size(176, 23);
            textBox_usernameS.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(135, 40);
            label1.Name = "label1";
            label1.Size = new Size(71, 15);
            label1.TabIndex = 0;
            label1.Text = "USER NAME";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(button_add);
            tabPage2.Controls.Add(textBox_passwordA);
            tabPage2.Controls.Add(textBox_usernameA);
            tabPage2.Controls.Add(label_password);
            tabPage2.Controls.Add(label_username);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(613, 321);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "tabPage2";
            tabPage2.UseVisualStyleBackColor = true;
            tabPage2.Click += tabPage2_Click;
            // 
            // button_add
            // 
            button_add.Location = new Point(210, 227);
            button_add.Name = "button_add";
            button_add.Size = new Size(194, 23);
            button_add.TabIndex = 2;
            button_add.Text = "ADD";
            button_add.UseVisualStyleBackColor = true;
            button_add.Click += button_add_Click;
            // 
            // textBox_passwordA
            // 
            textBox_passwordA.Location = new Point(210, 173);
            textBox_passwordA.Name = "textBox_passwordA";
            textBox_passwordA.Size = new Size(194, 23);
            textBox_passwordA.TabIndex = 1;
            // 
            // textBox_usernameA
            // 
            textBox_usernameA.Location = new Point(210, 92);
            textBox_usernameA.Name = "textBox_usernameA";
            textBox_usernameA.Size = new Size(194, 23);
            textBox_usernameA.TabIndex = 1;
            // 
            // label_password
            // 
            label_password.AutoSize = true;
            label_password.Location = new Point(210, 155);
            label_password.Name = "label_password";
            label_password.Size = new Size(57, 15);
            label_password.TabIndex = 0;
            label_password.Text = "Password";
            // 
            // label_username
            // 
            label_username.AutoSize = true;
            label_username.Location = new Point(210, 74);
            label_username.Name = "label_username";
            label_username.Size = new Size(59, 15);
            label_username.TabIndex = 0;
            label_username.Text = "username";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(button_delete);
            tabPage3.Controls.Add(button_update);
            tabPage3.Controls.Add(textBox_passwordU);
            tabPage3.Controls.Add(textBox_usdernameU);
            tabPage3.Controls.Add(label2);
            tabPage3.Controls.Add(label3);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(613, 321);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "tabPage3";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // button_delete
            // 
            button_delete.Location = new Point(332, 214);
            button_delete.Name = "button_delete";
            button_delete.Size = new Size(102, 23);
            button_delete.TabIndex = 7;
            button_delete.Text = "Delete";
            button_delete.UseVisualStyleBackColor = true;
            // 
            // button_update
            // 
            button_update.Location = new Point(212, 214);
            button_update.Name = "button_update";
            button_update.Size = new Size(102, 23);
            button_update.TabIndex = 7;
            button_update.Text = "Update";
            button_update.UseVisualStyleBackColor = true;
            // 
            // textBox_passwordU
            // 
            textBox_passwordU.Location = new Point(224, 160);
            textBox_passwordU.Name = "textBox_passwordU";
            textBox_passwordU.Size = new Size(194, 23);
            textBox_passwordU.TabIndex = 5;
            // 
            // textBox_usdernameU
            // 
            textBox_usdernameU.Location = new Point(224, 79);
            textBox_usdernameU.Name = "textBox_usdernameU";
            textBox_usdernameU.Size = new Size(194, 23);
            textBox_usdernameU.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(224, 142);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(224, 61);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 4;
            label3.Text = "username";
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(button_show);
            tabPage4.Controls.Add(dataGridView2);
            tabPage4.Location = new Point(4, 4);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(613, 321);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "tabPage4";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(75, 23);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(495, 211);
            dataGridView2.TabIndex = 0;
            // 
            // button_show
            // 
            button_show.Location = new Point(254, 256);
            button_show.Name = "button_show";
            button_show.Size = new Size(126, 36);
            button_show.TabIndex = 1;
            button_show.Text = "button2";
            button_show.UseVisualStyleBackColor = true;
            button_show.Click += button_show_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label_username;
        private Button button_add;
        private TextBox textBox_passwordA;
        private TextBox textBox_usernameA;
        private Label label_password;
        private Button button1;
        private TextBox textBox_usernameS;
        private Label label1;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private TabPage tabPage3;
        private Button button_delete;
        private Button button_update;
        private TextBox textBox_passwordU;
        private TextBox textBox_usdernameU;
        private Label label2;
        private Label label3;
        private TabPage tabPage4;
        private Button button_show;
        private DataGridView dataGridView2;
    }
}