﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public String conString = "Data Source=.\\sqlexpress;Initial Catalog=akila;Integrated Security=True;Encrypt=False";
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button_add_Click(object sender, EventArgs e)
        {


            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();
                    if (con.State == System.Data.ConnectionState.Open)
                    {
                        string q = "INSERT INTO Table_1(username,password) VALUES (@username, @password)";
                        using (SqlCommand cmd = new SqlCommand(q, con))
                        {
                            cmd.Parameters.AddWithValue("@username", textBox_usernameA.Text.ToString());
                            cmd.Parameters.AddWithValue("@password", textBox_passwordA.Text.ToString());

                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                MessageBox.Show("Data Inserted Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        private void button_show_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();
                    string q = "SELECT * FROM Table_1";
                    using (SqlCommand cmd = new SqlCommand(q, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView2.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }
    }
}
